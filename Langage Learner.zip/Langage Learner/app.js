const port = 3000;

var express = require('express'),
app = express();
var mongoose=require('mongoose');

mongoose.connect('mongodb://localhost:27017/test',{useNewUrlParser: true});

var mySchema=mongoose.Schema({
    emailid:String, 
    password:String
});

var langSchema=mongoose.Schema({
    Language:String,
    Words:Array
});

var UserInfo = mongoose.model('test_col',mySchema);
var LangInfo = mongoose.model('Languages',langSchema);

var bodyParser = require('body-parser');

var langid;

app.use(bodyParser.urlencoded({
   extended: false
}));

app.use(bodyParser.json());

app.get('/', function(req, res){
 res.sendfile("index.html");
});

app.get('/home', function(req, res){
    res.sendfile("home.html");
   });

app.get('/languages', function(req, res){
    res.sendfile("languages.html");
});

app.post('/languages/languageDisplay', function(req, res){
    langid=req.body.language;
    res.sendfile("languageDisplay.html");
});


app.post('/languages/languageDisplay/language',function(req,res){
    var languageVal=langid;
    LangInfo.findOne({Language:languageVal},function(err,lang){
        if(err){
            console.log(err);
            return res.status(500).send();
        }
        if(!lang){
            console.log("Language not found");
            return res.status(404).send();
        }
        res.send(lang); 
    })
});


app.post('/',function(req,res){
   var emailID = req.body.emailID;
   var password = req.body.password;

   UserInfo.findOne({emailid:emailID,password:password},function(err,user){
       if(err){
           console.log(err);
           return res.status(500).send();
       }

       if(!user){

        var newUser=new UserInfo();

        newUser.emailid=emailID;
        newUser.password=password;
        newUser.save(function(err,savedObject){
            if(err){
                console.log(err);
                res.status(500).send();
            }        
        });
       console.log(password);
       console.log(emailID);
       }
       if(user){
       console.log("Welcome Back!");
       }
       return res.redirect('/home');
       return res.status(200).send();
       
   })
});

app.listen(port);

